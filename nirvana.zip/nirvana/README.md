# Nirvana Brain Scan Web App

## Overview

This repository provides a FastAPI web service to:
- accept DICOM brain scan uploads
- preprocess the scans into normalized 3D volumes
- run inference via a model abstraction

## Install & run locally

1. Create virtual environment

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

2. Run the app

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

3. Health check

```bash
curl http://localhost:8000/health
```

4. Predict

```bash
curl -X POST "http://localhost:8000/predict" -F "files=@/path/to/slice1.dcm" -F "files=@/path/to/slice2.dcm"
```

## Model integration

- `app/model.py` contains `load_model` and `predict`.
- Replace `DummyModel` with your actual model class and weights load logic.

## Deployment (Docker)

Build & run:

```bash
docker build -t nirvana-brain-predictor .
docker run -p 8000:8000 nirvana-brain-predictor
```
