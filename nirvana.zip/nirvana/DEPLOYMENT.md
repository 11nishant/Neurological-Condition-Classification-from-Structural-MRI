# Deployment Guide

## Local Development

### 1. Setup
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run Server
```bash
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 3. Test API
```bash
# Health check
curl http://localhost:8000/health

# Docs (interactive)
http://localhost:8000/docs
```

---

## Docker Deployment

### Build Image
```bash
docker build -t nirvana-brain-predictor:latest .
```

### Run Container
```bash
docker run -p 8000:8000 nirvana-brain-predictor:latest
```

---

## Cloud Deployment Options

### Option 1: AWS (EC2 + Docker)
```bash
# SSH into EC2 instance
ssh -i key.pem ec2-user@your-instance-ip

# Clone repo and run
git clone <your-repo>
cd nirvana
docker build -t nirvana .
docker run -d -p 80:8000 nirvana
```

### Option 2: AWS (Elastic Container Service - ECS)
1. Push image to ECR
2. Create ECS task definition
3. Deploy via Amazon ECS

### Option 3: Google Cloud Run
```bash
gcloud builds submit --tag gcr.io/YOUR_PROJECT/nirvana
gcloud run deploy nirvana \
  --image gcr.io/YOUR_PROJECT/nirvana \
  --platform managed \
  --region us-central1 \
  --memory 2Gi
```

### Option 4: Heroku
```bash
heroku login
heroku create nirvana-brain-predictor
git push heroku main
```

### Option 5: Azure Container Instances
```bash
az container create \
  --resource-group myResourceGroup \
  --name nirvana \
  --image mcr.microsoft.com/azuredocs/aci-helloworld \
  --ports 80 8000
```

---

## Production Considerations

### 1. Environment Variables
Create `.env`:
```
MODEL_PATH=/app/models/best.pth
LOG_LEVEL=info
```

### 2. Scaling
- Use Gunicorn with multiple workers:
```bash
gunicorn -w 4 -b 0.0.0.0:8000 app.main:app
```

### 3. Monitoring & Logging
- Add Prometheus metrics
- Use ELK Stack or DataDog
- Configure health checks

### 4. Security
- Use HTTPS/TLS
- Add authentication (API keys, OAuth)
- Rate limiting

---

## Model Integration

Replace `app/model.py` with your actual model:
```python
def load_model(path: str):
    model = torch.load(path)  # or your framework
    return model

def predict(volume: np.ndarray, model):
    # Your prediction logic
    return {"class": 0, "confidence": 0.95}
```

Set model path in `app/main.py`:
```python
loaded_model = model.load_model("path/to/model_weights.pth")
```

---

## Testing

Run tests locally:
```bash
pip install pytest pytest-asyncio
pytest tests/ -v
```

---

## Troubleshooting

### Port already in use
```bash
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### DICOM parsing errors
- Ensure DICOM files are valid (use `pydicom.dcmread()` to test)
- Check for proper InstanceNumber ordering

### Memory issues
- Increase container memory limits
- Optimize 3D volume sizes (currently 128x128)
