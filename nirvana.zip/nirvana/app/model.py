import numpy as np
from typing import Dict, Optional

try:
    import torch
    import torch.nn.functional as F
except ImportError:
    torch = None


class DummyModel:
    def predict(self, volume: np.ndarray) -> Dict[str, float]:
        score = float(np.mean(volume))
        return {
            "normal": float(1.0 - score),
            "abnormal": float(score),
        }


def load_model(path: Optional[str] = None):
    if torch is None or path is None:
        return DummyModel()

    try:
        model = torch.load(path, map_location="cpu")
        model.eval()
        return model
    except Exception:
        return DummyModel()


def predict(volume: np.ndarray, model=None) -> Dict[str, float]:
    if model is None:
        model = DummyModel()

    if hasattr(model, "predict"):
        return model.predict(volume)

    if torch is not None and isinstance(volume, np.ndarray):
        x = torch.tensor(volume, dtype=torch.float32)
        if x.ndim == 3:
            x = x.unsqueeze(0).unsqueeze(0)
        elif x.ndim == 4:
            x = x.unsqueeze(0)
        try:
            logits = model(x)
            if isinstance(logits, tuple):
                logits = logits[0]
            probs = F.softmax(logits, dim=-1).detach().cpu().numpy()[0]
            return {"class_0": float(probs[0]), "class_1": float(probs[1])}
        except Exception:
            return DummyModel().predict(volume)

    return DummyModel().predict(volume)
