import re
from io import BytesIO
from typing import List, Tuple

import cv2
import numpy as np
import pydicom


def preprocess_dicom(ds: pydicom.dataset.FileDataset) -> np.ndarray:
    img = ds.pixel_array.astype(np.float32)

    img = (img - np.min(img)) / (np.max(img) - np.min(img) + 1e-8)
    img = (img * 255).astype(np.uint8)

    _, thresh = cv2.threshold(img, 30, 255, cv2.THRESH_BINARY)
    brain = cv2.bitwise_and(img, img, mask=thresh)

    brain = cv2.resize(brain, (128, 128), interpolation=cv2.INTER_AREA)
    brain = brain.astype(np.float32) / 255.0

    return brain


def load_dicom_bytes(data: bytes) -> pydicom.dataset.FileDataset:
    return pydicom.dcmread(BytesIO(data), force=True)


def make_3d_volume(dicom_datasets: List[pydicom.dataset.FileDataset]) -> np.ndarray:
    slices: List[Tuple[int, np.ndarray]] = []

    for ds in dicom_datasets:
        try:
            image = preprocess_dicom(ds)
            instance_number = int(getattr(ds, "InstanceNumber", 0)) if hasattr(ds, "InstanceNumber") else 0
            slices.append((instance_number, image))
        except Exception:
            continue

    if len(slices) == 0:
        raise ValueError("No valid DICOM slices after preprocessing")

    slices.sort(key=lambda x: x[0])
    volume = np.stack([s[1] for s in slices], axis=0)
    return volume


def volume_from_files(file_contents: List[bytes]) -> np.ndarray:
    datasets = [load_dicom_bytes(data) for data in file_contents]
    return make_3d_volume(datasets)
