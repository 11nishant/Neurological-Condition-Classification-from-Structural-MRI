from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from starlette.requests import Request
from typing import List

from app import model, preprocess

app = FastAPI(title="Nirvana Brain-Scan Predictor")

loaded_model = model.load_model(None)


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/predict")
async def predict(files: List[UploadFile] = File(...)):
    if len(files) == 0:
        raise HTTPException(status_code=400, detail="At least one DICOM file is required")

    try:
        file_buffers = [await f.read() for f in files]
        volume = preprocess.volume_from_files(file_buffers)

        result = model.predict(volume, model=loaded_model)

        return JSONResponse({"prediction": result})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/predict-single")
async def predict_single(file: UploadFile = File(...)):
    if file.content_type not in ["application/dicom", "application/octet-stream", "application/dicom-seg"]:
        raise HTTPException(status_code=400, detail="Upload a DICOM file")

    raw = await file.read()
    try:
        ds = preprocess.load_dicom_bytes(raw)
        volume = preprocess.make_3d_volume([ds])
        result = model.predict(volume, model=loaded_model)
        return JSONResponse({"prediction": result})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
