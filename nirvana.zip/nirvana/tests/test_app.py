import pytest
from fastapi.testclient import TestClient
from app.main import app
import numpy as np

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_predict_no_files():
    response = client.post("/predict")
    assert response.status_code == 422


def test_predict_single_slice():
    from app import preprocess
    import pydicom
    from pydicom.dataset import FileDataset, Dataset
    import io

    ds = FileDataset("/tmp/test.dcm", {}, preamble=b"\0" * 128, is_implicit_VR=True, is_little_endian=True)
    ds.PatientName = "Test"
    ds.PatientID = "123"
    ds.add_new(0x00100010, "PN", "Test Patient")
    pixel_array = np.random.randint(0, 255, (128, 128), dtype=np.uint8)

    ds.file_meta = Dataset()
    ds.file_meta.MediaStorageSOPClassUID = "1.2.840.10008.5.1.4.1.1.2"
    ds.file_meta.MediaStorageSOPInstanceUID = "1.2.3"
    ds.file_meta.TransferSyntaxUID = "1.2.840.10008.1.2"
    ds.is_implicit_VR = True
    ds.is_little_endian = True

    ds.SOPClassUID = "1.2.840.10008.5.1.4.1.1.2"
    ds.SOPInstanceUID = "1.2.3"
    ds.add_new(0x7FE00010, "OB", pixel_array.tobytes())
    ds.Rows = 128
    ds.Columns = 128
    ds.BitsAllocated = 8
    ds.BitsStored = 8
    ds.HighBit = 7
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.InstanceNumber = 1

    buffer = io.BytesIO()
    ds.save_as(buffer, write_like_original=False)
    buffer.seek(0)

    response = client.post("/predict-single", files={"file": ("test.dcm", buffer, "application/dicom")})
    assert response.status_code == 200
    assert "prediction" in response.json()
    assert isinstance(response.json()["prediction"], dict)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
